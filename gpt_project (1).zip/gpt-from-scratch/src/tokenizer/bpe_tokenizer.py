
class SimpleTokenizer:
    def __init__(self):
        self.vocab = {}

    def build_vocab(self, text):
        words = text.split()
        self.vocab = {w:i for i,w in enumerate(set(words))}

    def encode(self, text):
        return [self.vocab.get(w,0) for w in text.split()]
