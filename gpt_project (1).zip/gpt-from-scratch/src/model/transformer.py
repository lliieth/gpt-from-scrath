
import torch
import torch.nn as nn
from .attention import SelfAttention

class TransformerBlock(nn.Module):
    def __init__(self, embed_size):
        super().__init__()
        self.attn = SelfAttention(embed_size)
        self.norm = nn.LayerNorm(embed_size)

    def forward(self, x):
        x = x + self.attn(x)
        return self.norm(x)
