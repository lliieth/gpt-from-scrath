
print("Running pretraining...")
