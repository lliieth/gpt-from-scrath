
# مشروع GPT عربي مبسط

هذا المشروع يشرح بناء نموذج Transformer بسيط باستخدام PyTorch.

المجلدات:

src/model        نموذج الشبكة العصبية
src/tokenizer    تقطيع النص
src/training     تدريب النموذج
src/evaluation   تقييم النموذج
src/demo         تجربة التوليد
