
import torch
from src.model.transformer import TransformerBlock

def train():

    print("بدء التدريب")

    model = TransformerBlock(64)

    x = torch.randn(2,10,64)

    out = model(x)

    print("ناتج النموذج:", out.shape)

if __name__ == "__main__":

    train()
