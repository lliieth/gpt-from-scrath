
def evaluate():

    print("تقييم النموذج")

    accuracy = 0.9

    print("الدقة:", accuracy)

if __name__ == "__main__":

    evaluate()
