
from src.tokenizer.simple_tokenizer import SimpleTokenizer

def run_demo():

    text = "مرحبا هذا مثال لنموذج لغة"

    tok = SimpleTokenizer()

    tok.build_vocab(text)

    tokens = tok.encode(text)

    print("التوكنز:", tokens)

    print("النص:", tok.decode(tokens))

if __name__ == "__main__":

    run_demo()
