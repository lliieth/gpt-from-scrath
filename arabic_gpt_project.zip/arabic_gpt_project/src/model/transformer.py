
import torch
import torch.nn as nn
from .attention import SelfAttention

class TransformerBlock(nn.Module):

    def __init__(self, embed_size):
        super().__init__()

        self.attn = SelfAttention(embed_size)

        self.norm1 = nn.LayerNorm(embed_size)
        self.norm2 = nn.LayerNorm(embed_size)

        self.ff = nn.Sequential(
            nn.Linear(embed_size, embed_size*4),
            nn.ReLU(),
            nn.Linear(embed_size*4, embed_size)
        )

    def forward(self, x):

        attn_out = self.attn(x)

        x = self.norm1(x + attn_out)

        ff_out = self.ff(x)

        out = self.norm2(x + ff_out)

        return out
