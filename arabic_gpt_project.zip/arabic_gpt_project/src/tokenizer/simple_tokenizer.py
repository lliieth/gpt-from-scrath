
class SimpleTokenizer:

    def __init__(self):

        self.vocab = {}
        self.inverse_vocab = {}

    def build_vocab(self, text):

        words = text.split()

        unique_words = sorted(list(set(words)))

        self.vocab = {w:i for i,w in enumerate(unique_words)}

        self.inverse_vocab = {i:w for w,i in self.vocab.items()}

    def encode(self, text):

        tokens = text.split()

        return [self.vocab.get(t,0) for t in tokens]

    def decode(self, tokens):

        return " ".join([self.inverse_vocab.get(t,"?") for t in tokens])
